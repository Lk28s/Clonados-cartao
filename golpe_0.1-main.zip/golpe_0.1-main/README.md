# golpe_0.1
Brincadeira a fim de criar um site que finge clonar seu cartão. Apenas para diversão enviando para amigos
